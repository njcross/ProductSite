from flask import Blueprint, request, jsonify
from app.models import Inventory
from app.utils.decorators import login_required, admin_required 
from app.extensions import db
import requests
import os

GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')
inventory_bp = Blueprint('inventory', __name__, url_prefix="/api/inventory")
def find_address(input_text):
    
    url = (
        'https://maps.googleapis.com/maps/api/place/findplacefromtext/json'
        f'?input={input_text}&inputtype=textquery&fields=formatted_address,geometry'
        f'&key={GOOGLE_API_KEY}'
    )

    try:
        res = requests.get(url)
        res_data = res.json()

        if res_data.get('status') != 'OK' or not res_data.get('candidates'):
            return jsonify({'error': 'Place not found'}), 404

        place = res_data['candidates'][0]
        return {
            'address': place['formatted_address'],
            'lat': place['geometry']['location']['lat'],
            'lng': place['geometry']['location']['lng'],
        }

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@inventory_bp.route('', methods=['POST'])
@admin_required
def create_inventory():
    data = request.json

    rtn = find_address(data['location'])
    if isinstance(rtn, tuple):  # means it's a (Response, status_code)
        return rtn

    data['coordinates'] = f"{rtn['lat']}, {rtn['lng']}"
    data['location'] = rtn['address']
    inv = Inventory(**data)
    db.session.add(inv)
    db.session.commit()
    return jsonify({'message': 'Inventory created', 'inventory': inv.id}), 201

@inventory_bp.route('', methods=['PUT'])
@admin_required
def edit_inventory():
    data = request.json
    inv = Inventory.query.filter_by(kit_id=data['kit_id'], location=data['location']).first()
    if not inv:
        return jsonify({'error': 'Inventory not found'}), 404
    inv.location_name = data.get('location_name', inv.location_name)
    inv.quantity = data.get('quantity', inv.quantity)
    rtn = find_address(data['location'])
    if isinstance(rtn, tuple):
        return rtn
    inv.coordinates = f"{rtn['lat']}, {rtn['lng']}"
    inv.location = rtn['address']

    db.session.commit()
    return jsonify({'message': 'Inventory updated'})

@inventory_bp.route('', methods=['DELETE'])
@admin_required
def delete_inventory():
    kit_id = request.args.get('kit_id')
    location = request.args.get('location')
    inv = Inventory.query.filter_by(kit_id=kit_id, location=location).first()
    if not inv:
        return jsonify({'error': 'Inventory not found'}), 404
    db.session.delete(inv)
    db.session.commit()
    return jsonify({'message': 'Inventory deleted'})

@inventory_bp.route('/decrement', methods=['POST'])
@login_required
def decrement_quantity():
    data = request.json
    inv = Inventory.query.filter_by(kit_id=data['kit_id'], location=data['location']).first()
    if not inv or inv.quantity <= 0:
        return jsonify({'error': 'Insufficient inventory'}), 400
    inv.quantity -= 1
    db.session.commit()
    return jsonify({'message': 'Inventory decremented', 'new_quantity': inv.quantity})

@inventory_bp.route('/<int:kit_id>', methods=['GET'])
def get_inventory_by_kit(kit_id):
    inventories = Inventory.query.filter_by(kit_id=kit_id).all()
    return jsonify([
        {
            'location': inv.location,
            'location_name': inv.location_name,
            'quantity': inv.quantity,
            'kit_id': inv.kit_id,
            'id':inv.id,
            'coordinates':inv.coordinates
        }
        for inv in inventories
    ])

@inventory_bp.route('', methods=['GET'])
def get_inventory():
    inventories = Inventory.query.all()
    return jsonify([
        {
            'location': inv.location,
            'location_name': inv.location_name,
            'quantity': inv.quantity,
            'kit_id': inv.kit_id,
            'id':inv.id,
            'coordinates':inv.coordinates
        }
        for inv in inventories
    ])

@inventory_bp.route('/item/<int:inventory_id>', methods=['GET'])
def get_inventory_by_id(inventory_id):
    inv = Inventory.query.get(inventory_id)
    if not inv:
        return jsonify({'error': 'Inventory not found'}), 404
    return jsonify({
        'id': inv.id,
        'kit_id': inv.kit_id,
        'location': inv.location,
        'location_name': inv.location_name,
        'quantity': inv.quantity,
        'coordinates': inv.coordinates
    })

# Flask route example
@inventory_bp.route("/locations")
def get_inventory_locations():
    locations = db.session.query(Inventory.location).distinct().all()
    return jsonify([loc[0] for loc in locations])